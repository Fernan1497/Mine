import javax.swing.JButton;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.AbstractButton;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;



	
public class MyFrame extends JFrame implements ActionListener
{
	JButton[]numButtons = new JButton[10];
	JButton[]functionButtons = new JButton[8];
	JTextField textfield = new JTextField();
	JButton decimalButton = new JButton(".");
	JButton addButton = new JButton("+");
	JButton equalButton = new JButton("=");
	JButton deleteButton = new JButton("Delete");
	JButton clearButton = new JButton("Clear");




	double num1=0;
	double num2=0;
	double result =0;
	char operator;


	JButton subButton = new JButton("-");
	JButton mulButton = new JButton("*");
	JButton divButton = new JButton("/");



	 
	public MyFrame()
	 
	
	{
		
		 		//JButton[]numButtons = new JButton[10];
				//JButton[]functionButtons = new JButton[8];
				//JTextField textfield = new JTextField();

				//JButton addButton,subButton,mulButton,divButton;
				//JButton decimalButton,equalButton,deleteButton,clearButton;
				//JLabel label = new JLabel();
				//textfield.setFont(new Font());


				
				ImageIcon image = new ImageIcon("logo.png");
				this.setSize(420, 550);
				this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				this.setTitle("Calculator");
				this.setResizable(false);
				this.setLayout(null);
				//this.pack();

				//this.add(label);
				//JTextField textfield = new JTextField();

				textfield.setBounds(50, 25, 300, 50);
				textfield.setEditable(false);
				

				
				//JButton addButton = new JButton("+");
				//JButton subButton = new JButton("-");
				//JButton mulButton = new JButton("*");
				//JButton divButton = new JButton("/");
				//JButton decimalButton = new JButton(".");
				//JButton equalButton = new JButton("=");
				//JButton deleteButton = new JButton("Delete");
				//JButton clearButton = new JButton("Clear");
				
				functionButtons[0]=addButton;
				functionButtons[1]=subButton;
				functionButtons[2]=mulButton;
				functionButtons[3]=divButton;
				functionButtons[4]=decimalButton;
				functionButtons[5]=equalButton;
				functionButtons[6]=deleteButton;
				functionButtons[7]=clearButton;
				
				for(int i = 0; i<8;i++)
				{
					functionButtons[i].addActionListener(this);
					functionButtons[i].setFocusable(false);
					
					
				}


				
				this.setIconImage(image.getImage());//chnae icon of frame
				this.getContentPane().setBackground(new Color(67,84,90));
				//this.setLayout(new GridLayout());
				
		        
		       
		        
		        
				
		        for(int i =0; i<10;i++)
		        {
		        	numButtons[i]= new JButton (String.valueOf(i));
		        	numButtons[i].addActionListener(this);
		        	numButtons[i].setFocusable(false);
		        	
		        }
		        JPanel panel = new JPanel();
		       panel.setBounds(50, 100, 300, 300);
		       panel.setLayout(new GridLayout(4,4,5,0));
		        
		        deleteButton.setBounds(50, 430, 145, 50);
		        clearButton.setBounds(205, 430, 150, 50);
		        this.add(deleteButton);
		        this.add(clearButton);
		        
		       
		        
				this.add(textfield);
				this.add(panel);
				
				panel.add(numButtons[1]);
				panel.add(numButtons[2]);
				panel.add(numButtons[3]);
				panel.add(addButton);
				panel.add(numButtons[4]);
				panel.add(numButtons[5]);
				panel.add(numButtons[6]);
				panel.add(subButton);
				panel.add(numButtons[7]);
				panel.add(numButtons[8]);
				panel.add(numButtons[9]);
				panel.add(mulButton);
				panel.add(numButtons[0]);
				panel.add(decimalButton);
				panel.add(divButton);
				panel.add(equalButton);

				

		        
				this.setVisible(true);

				
				//label.setText("Please enter a number");
				//label.setForeground(Color.WHITE);
				//label.setHorizontalAlignment(JLabel.NORTH_EAST);
				//label.setVerticalAlignment(JLabel.TOP);
				//label.setFont(new Font("Times New Roman",Font.BOLD,20));
				
		
	}
	 public void actionPerformed(ActionEvent e)//JButton[] numButtons, JTextField textfield)
	 {
		 for(int i = 0; i<10;i++)
			 
		 {
			 if (e.getSource()==numButtons[i])
			 {
				 textfield.setText(textfield.getText().concat(String.valueOf(i)));
			 }
			 
		 }
		 if(e.getSource()==decimalButton)
		 {
			 textfield.setText(textfield.getText().concat(String.valueOf(".")));
		 }
		 if(e.getSource()==addButton)
		 {
			
			num1=Double.parseDouble(textfield.getText());
			operator = '+';
			 textfield.setText("");
		 }
		
		 
		 if(e.getSource()==subButton)
		 {
			
			num1=Double.parseDouble(textfield.getText());
			operator = '-';
			 textfield.setText("");

		 }
		 if(e.getSource()==mulButton)
		 {
			
			num1=Double.parseDouble(textfield.getText());
			operator = '*';
			textfield.setText("");

		 }
		 
		 if(e.getSource()==divButton)
		 {
			
			num1=Double.parseDouble(textfield.getText());
			operator = '/';
			textfield.setText("");

		 }
		 
		 
		 
		 if(e.getSource()==equalButton)
		 {
			
			num2=Double.parseDouble(textfield.getText());

			 
		 
		 
		 switch(operator)
		 {
		 case'+':
			 result=num1+num2;
			 break;
		 case'-':
			 result=num1-num2;
			 break;
		 case'*':
			 result=num1*num2;
			 break;
		 case'/':
			 result=num1/num2;
			 break;
			
		 }
		 textfield.setText(String.valueOf(result));
		 num1=result;
		 }
		 if(e.getSource()==clearButton) {
				textfield.setText("");
			}
			if(e.getSource()==deleteButton) {
				String string = textfield.getText();
				textfield.setText("");
				for(int i=0;i<string.length()-1;i++) {
					textfield.setText(textfield.getText()+string.charAt(i));
				}
		 

	 }

	 }
}